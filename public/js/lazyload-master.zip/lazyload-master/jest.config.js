// jest.config.js
module.exports = {
	//verbose: true,
	testMatch: ["**/__tests__/*.js"]
};
